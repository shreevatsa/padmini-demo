#: 1.1.27
#: TODO: add others
SARVA_ADI = {
    "sarva",
    "viSva",
    "uBa",
    "uBaya",
    "qatara",
    "qatama",
    "anya",
    "anyatara",
    "itara",
    "tvat",
    "tva",
    "nema",
    "sama",
    "sima",
    "pUrva",
    "para",
    "avara",
    "dakziRa",
    "uttara",
    "apara",
    "aDara",
    "sva",
    "antara",
    "tyad",
    "tad",
    "yad",
    "etad",
    "idam",
    "adas",
    "eka",
    "dvi",
    "yuzmad",
    "asmad",
    "Bavatu~",
    "kim",
}

USES_DATARA_DATAMA = {
    "katara",
    "yatara",
    "tatara",
    "ekatara",
    "katama",
    "yatama",
    "tatama",
    "ekatama",
}

PRATHAMA_ADI = {
    "praTama",
    "carama",
    # "taya",
    "alpa",
    "arDa",
    "katipaya",
    # "nema",
}

PURVA_ADI = {
    "pUrva",
    "para",
    "avara",
    "dakziRa",
    "uttara",
    "apara",
    "aDara",
    "sva",
    "antara",
}

DATARA_ADI = {"qatara", "qatama", "anya", "anyatara", "itara"}
